
  # Smart Healthcare Management Platform

  This is a code bundle for Smart Healthcare Management Platform. The original project is available at https://www.figma.com/design/5IxAhGchaY4FjpbAF1ZYif/Smart-Healthcare-Management-Platform.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  