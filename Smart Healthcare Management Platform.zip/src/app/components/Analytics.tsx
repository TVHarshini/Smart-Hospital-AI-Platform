import { BarChart, Bar, LineChart, Line, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend, Area, AreaChart } from "recharts";
import { TrendingUp, TrendingDown, Users, Clock, CheckCircle, AlertCircle, Brain, Zap } from "lucide-react";
import { Badge } from "./ui/badge";

const weeklyData = [
  { day: "Mon", requests: 145, resolved: 132, delayed: 13 },
  { day: "Tue", requests: 168, resolved: 155, delayed: 13 },
  { day: "Wed", requests: 152, resolved: 140, delayed: 12 },
  { day: "Thu", requests: 178, resolved: 165, delayed: 13 },
  { day: "Fri", requests: 195, resolved: 180, delayed: 15 },
  { day: "Sat", requests: 125, resolved: 118, delayed: 7 },
  { day: "Sun", requests: 98, resolved: 93, delayed: 5 },
];

const departmentPerformance = [
  { name: "Laboratory", efficiency: 92, avgTime: 2.1, satisfaction: 4.5 },
  { name: "Billing", efficiency: 78, avgTime: 3.2, satisfaction: 3.8 },
  { name: "Pharmacy", efficiency: 88, avgTime: 1.8, satisfaction: 4.6 },
  { name: "Insurance", efficiency: 65, avgTime: 4.5, satisfaction: 3.2 },
  { name: "Radiology", efficiency: 82, avgTime: 2.8, satisfaction: 4.1 },
];

const categoryDistribution = [
  { name: "Lab Reports", value: 345, color: "#8b5cf6" },
  { name: "Billing", value: 280, color: "#3b82f6" },
  { name: "Pharmacy", value: 195, color: "#10b981" },
  { name: "Insurance", value: 145, color: "#f59e0b" },
  { name: "Appointments", value: 125, color: "#ef4444" },
  { name: "Emergency", value: 45, color: "#ec4899" },
];

const hourlyTrend = [
  { hour: "8 AM", volume: 25 },
  { hour: "9 AM", volume: 45 },
  { hour: "10 AM", volume: 62 },
  { hour: "11 AM", volume: 78 },
  { hour: "12 PM", volume: 85 },
  { hour: "1 PM", volume: 72 },
  { hour: "2 PM", volume: 88 },
  { hour: "3 PM", volume: 95 },
  { hour: "4 PM", volume: 82 },
  { hour: "5 PM", volume: 68 },
  { hour: "6 PM", volume: 45 },
];

export default function Analytics() {
  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-3xl font-bold text-white mb-2">Data Science Analytics</h2>
        <p className="text-gray-400">Comprehensive hospital performance insights and predictions</p>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-gradient-to-br from-blue-500/20 to-blue-600/20 backdrop-blur-sm border border-blue-500/30 rounded-xl p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="p-3 bg-blue-500/30 rounded-lg">
              <Users className="h-6 w-6 text-blue-400" />
            </div>
            <TrendingUp className="h-5 w-5 text-green-400" />
          </div>
          <p className="text-gray-400 text-sm mb-1">Total Requests (Week)</p>
          <p className="text-3xl font-bold text-white">1,061</p>
          <p className="text-green-400 text-sm mt-2">+15.3% vs last week</p>
        </div>

        <div className="bg-gradient-to-br from-green-500/20 to-green-600/20 backdrop-blur-sm border border-green-500/30 rounded-xl p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="p-3 bg-green-500/30 rounded-lg">
              <CheckCircle className="h-6 w-6 text-green-400" />
            </div>
            <TrendingUp className="h-5 w-5 text-green-400" />
          </div>
          <p className="text-gray-400 text-sm mb-1">Resolution Rate</p>
          <p className="text-3xl font-bold text-white">92.8%</p>
          <p className="text-green-400 text-sm mt-2">+3.2% improvement</p>
        </div>

        <div className="bg-gradient-to-br from-orange-500/20 to-orange-600/20 backdrop-blur-sm border border-orange-500/30 rounded-xl p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="p-3 bg-orange-500/30 rounded-lg">
              <Clock className="h-6 w-6 text-orange-400" />
            </div>
            <TrendingDown className="h-5 w-5 text-green-400" />
          </div>
          <p className="text-gray-400 text-sm mb-1">Avg Response Time</p>
          <p className="text-3xl font-bold text-white">2.4h</p>
          <p className="text-green-400 text-sm mt-2">-22% faster</p>
        </div>

        <div className="bg-gradient-to-br from-red-500/20 to-red-600/20 backdrop-blur-sm border border-red-500/30 rounded-xl p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="p-3 bg-red-500/30 rounded-lg">
              <AlertCircle className="h-6 w-6 text-red-400" />
            </div>
            <TrendingDown className="h-5 w-5 text-green-400" />
          </div>
          <p className="text-gray-400 text-sm mb-1">Delayed Cases</p>
          <p className="text-3xl font-bold text-white">78</p>
          <p className="text-green-400 text-sm mt-2">-18% reduction</p>
        </div>
      </div>

      {/* Charts Row 1 */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Weekly Trend */}
        <div className="bg-slate-900/50 backdrop-blur-sm border border-slate-700/50 rounded-xl p-6">
          <div className="mb-6">
            <h3 className="text-xl font-bold text-white mb-1">Weekly Request Trend</h3>
            <p className="text-gray-400 text-sm">Requests vs Resolved comparison</p>
          </div>
          <ResponsiveContainer width="100%" height={280}>
            <AreaChart data={weeklyData}>
              <defs>
                <linearGradient id="colorRequests" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.3}/>
                  <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
                </linearGradient>
                <linearGradient id="colorResolved" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#10b981" stopOpacity={0.3}/>
                  <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
              <XAxis dataKey="day" stroke="#9ca3af" />
              <YAxis stroke="#9ca3af" />
              <Tooltip 
                contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #475569', borderRadius: '8px' }}
                labelStyle={{ color: '#e5e7eb' }}
              />
              <Legend />
              <Area 
                type="monotone" 
                dataKey="requests" 
                stroke="#3b82f6" 
                strokeWidth={2}
                fillOpacity={1}
                fill="url(#colorRequests)"
                name="Total Requests"
              />
              <Area 
                type="monotone" 
                dataKey="resolved" 
                stroke="#10b981" 
                strokeWidth={2}
                fillOpacity={1}
                fill="url(#colorResolved)"
                name="Resolved"
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Request Category Distribution */}
        <div className="bg-slate-900/50 backdrop-blur-sm border border-slate-700/50 rounded-xl p-6">
          <div className="mb-6">
            <h3 className="text-xl font-bold text-white mb-1">Request Categories</h3>
            <p className="text-gray-400 text-sm">Distribution by type</p>
          </div>
          <div className="flex items-center">
            <ResponsiveContainer width="60%" height={280}>
              <PieChart>
                <Pie
                  data={categoryDistribution}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  outerRadius={100}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {categoryDistribution.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip 
                  contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #475569', borderRadius: '8px' }}
                />
              </PieChart>
            </ResponsiveContainer>
            <div className="flex-1 space-y-2">
              {categoryDistribution.map((cat, index) => (
                <div key={index} className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="h-3 w-3 rounded-full" style={{ backgroundColor: cat.color }}></div>
                    <span className="text-sm text-gray-300">{cat.name}</span>
                  </div>
                  <span className="text-sm text-white font-medium">{cat.value}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Department Performance */}
      <div className="bg-slate-900/50 backdrop-blur-sm border border-slate-700/50 rounded-xl p-6">
        <div className="mb-6">
          <h3 className="text-xl font-bold text-white mb-1">Department Performance Analysis</h3>
          <p className="text-gray-400 text-sm">Efficiency metrics and satisfaction scores</p>
        </div>
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={departmentPerformance}>
            <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
            <XAxis dataKey="name" stroke="#9ca3af" />
            <YAxis stroke="#9ca3af" />
            <Tooltip 
              contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #475569', borderRadius: '8px' }}
              labelStyle={{ color: '#e5e7eb' }}
            />
            <Legend />
            <Bar dataKey="efficiency" fill="#8b5cf6" radius={[8, 8, 0, 0]} name="Efficiency %" />
          </BarChart>
        </ResponsiveContainer>
      </div>

      {/* Hourly Traffic & AI Predictions */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Hourly Traffic */}
        <div className="lg:col-span-2 bg-slate-900/50 backdrop-blur-sm border border-slate-700/50 rounded-xl p-6">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h3 className="text-xl font-bold text-white mb-1">Hourly Traffic Pattern</h3>
              <p className="text-gray-400 text-sm">Peak hour analysis</p>
            </div>
            <Badge className="bg-purple-500/20 text-purple-400 border-purple-500/30">
              <Brain className="h-3 w-3 mr-1" />
              AI ANALYZED
            </Badge>
          </div>
          <ResponsiveContainer width="100%" height={250}>
            <LineChart data={hourlyTrend}>
              <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
              <XAxis dataKey="hour" stroke="#9ca3af" />
              <YAxis stroke="#9ca3af" />
              <Tooltip 
                contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #475569', borderRadius: '8px' }}
                labelStyle={{ color: '#e5e7eb' }}
              />
              <Line 
                type="monotone" 
                dataKey="volume" 
                stroke="#8b5cf6" 
                strokeWidth={3}
                dot={{ fill: '#8b5cf6', r: 4 }}
                activeDot={{ r: 6 }}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>

        {/* AI Predictions */}
        <div className="bg-slate-900/50 backdrop-blur-sm border border-slate-700/50 rounded-xl p-6">
          <div className="flex items-center gap-2 mb-6">
            <Brain className="h-5 w-5 text-purple-400" />
            <h3 className="text-lg font-bold text-white">AI Predictions</h3>
          </div>
          <div className="space-y-4">
            <div className="p-4 bg-blue-500/10 border border-blue-500/20 rounded-lg">
              <div className="flex items-center gap-2 mb-2">
                <TrendingUp className="h-4 w-4 text-blue-400" />
                <span className="text-sm font-semibold text-blue-400">Tomorrow's Volume</span>
              </div>
              <p className="text-2xl font-bold text-white mb-1">~245</p>
              <p className="text-xs text-gray-400">+15% from today</p>
            </div>

            <div className="p-4 bg-orange-500/10 border border-orange-500/20 rounded-lg">
              <div className="flex items-center gap-2 mb-2">
                <Clock className="h-4 w-4 text-orange-400" />
                <span className="text-sm font-semibold text-orange-400">Peak Hour</span>
              </div>
              <p className="text-2xl font-bold text-white mb-1">2-3 PM</p>
              <p className="text-xs text-gray-400">Highest traffic expected</p>
            </div>

            <div className="p-4 bg-purple-500/10 border border-purple-500/20 rounded-lg">
              <div className="flex items-center gap-2 mb-2">
                <Zap className="h-4 w-4 text-purple-400" />
                <span className="text-sm font-semibold text-purple-400">Optimization</span>
              </div>
              <p className="text-sm text-gray-300">
                AI suggests allocating 2 more staff to Billing dept.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Department Detailed Table */}
      <div className="bg-slate-900/50 backdrop-blur-sm border border-slate-700/50 rounded-xl p-6">
        <h3 className="text-xl font-bold text-white mb-6">Detailed Department Metrics</h3>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-slate-700">
                <th className="text-left text-gray-400 text-sm font-medium pb-3">Department</th>
                <th className="text-left text-gray-400 text-sm font-medium pb-3">Efficiency</th>
                <th className="text-left text-gray-400 text-sm font-medium pb-3">Avg Time</th>
                <th className="text-left text-gray-400 text-sm font-medium pb-3">Satisfaction</th>
                <th className="text-left text-gray-400 text-sm font-medium pb-3">Status</th>
              </tr>
            </thead>
            <tbody>
              {departmentPerformance.map((dept, index) => (
                <tr key={index} className="border-b border-slate-800/50">
                  <td className="py-4 text-white font-medium">{dept.name}</td>
                  <td className="py-4">
                    <div className="flex items-center gap-2">
                      <div className="flex-1 h-2 bg-slate-800 rounded-full overflow-hidden max-w-[100px]">
                        <div 
                          className={`h-full ${
                            dept.efficiency >= 85 ? 'bg-green-500' : 
                            dept.efficiency >= 70 ? 'bg-yellow-500' : 'bg-red-500'
                          }`}
                          style={{ width: `${dept.efficiency}%` }}
                        ></div>
                      </div>
                      <span className="text-white text-sm">{dept.efficiency}%</span>
                    </div>
                  </td>
                  <td className="py-4 text-gray-300">{dept.avgTime}h</td>
                  <td className="py-4">
                    <span className="text-yellow-400">★ {dept.satisfaction}</span>
                  </td>
                  <td className="py-4">
                    <Badge className={
                      dept.efficiency >= 85 
                        ? "bg-green-500/20 text-green-400 border-green-500/30"
                        : dept.efficiency >= 70
                        ? "bg-yellow-500/20 text-yellow-400 border-yellow-500/30"
                        : "bg-red-500/20 text-red-400 border-red-500/30"
                    }>
                      {dept.efficiency >= 85 ? 'Excellent' : dept.efficiency >= 70 ? 'Good' : 'Needs Improvement'}
                    </Badge>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
