import { useState } from "react";
import { Calendar, Clock, User, Video, Building2, FileText, CheckCircle } from "lucide-react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Textarea } from "./ui/textarea";
import { Badge } from "./ui/badge";

interface Appointment {
  id: string;
  doctorName: string;
  specialization: string;
  type: "video" | "in-person";
  date: string;
  time: string;
  reason: string;
  status: "scheduled" | "confirmed" | "completed";
  prescription?: string;
}

export default function Appointments() {
  const [appointments, setAppointments] = useState<Appointment[]>([
    {
      id: "APT-001",
      doctorName: "Dr. Sarah Johnson",
      specialization: "General Physician",
      type: "video",
      date: "2026-03-01",
      time: "10:00 AM",
      reason: "Regular checkup",
      status: "confirmed"
    },
    {
      id: "APT-002",
      doctorName: "Dr. Michael Chen",
      specialization: "Cardiologist",
      type: "in-person",
      date: "2026-03-03",
      time: "2:30 PM",
      reason: "Heart consultation",
      status: "scheduled"
    }
  ]);

  const [showBooking, setShowBooking] = useState(false);
  const [selectedSpecialization, setSelectedSpecialization] = useState("");
  const [consultationType, setConsultationType] = useState<"video" | "in-person">("video");
  const [appointmentDate, setAppointmentDate] = useState("");
  const [appointmentTime, setAppointmentTime] = useState("");
  const [reason, setReason] = useState("");

  const specializations = [
    { name: "General Physician", icon: "👨‍⚕️", available: 8 },
    { name: "Cardiologist", icon: "❤️", available: 3 },
    { name: "Dermatologist", icon: "🧴", available: 5 },
    { name: "Pediatrician", icon: "👶", available: 6 },
    { name: "Orthopedic", icon: "🦴", available: 4 },
    { name: "Neurologist", icon: "🧠", available: 2 }
  ];

  const doctors = [
    { name: "Dr. Sarah Johnson", rating: 4.8, available: "9 AM - 5 PM" },
    { name: "Dr. Michael Chen", rating: 4.9, available: "10 AM - 6 PM" },
    { name: "Dr. Priya Sharma", rating: 4.7, available: "8 AM - 4 PM" }
  ];

  const handleBookAppointment = () => {
    const newAppointment: Appointment = {
      id: `APT-${String(appointments.length + 1).padStart(3, '0')}`,
      doctorName: doctors[Math.floor(Math.random() * doctors.length)].name,
      specialization: selectedSpecialization,
      type: consultationType,
      date: appointmentDate,
      time: appointmentTime,
      reason,
      status: "scheduled"
    };

    setAppointments([newAppointment, ...appointments]);
    setShowBooking(false);
    
    // Reset form
    setSelectedSpecialization("");
    setAppointmentDate("");
    setAppointmentTime("");
    setReason("");
  };

  const getStatusColor = (status: string) => {
    const colors = {
      scheduled: "bg-blue-500/20 text-blue-400 border-blue-500/30",
      confirmed: "bg-green-500/20 text-green-400 border-green-500/30",
      completed: "bg-gray-500/20 text-gray-400 border-gray-500/30"
    };
    return colors[status as keyof typeof colors];
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold text-white mb-2">Doctor Appointments</h2>
          <p className="text-gray-400">24/7 online and in-person consultations</p>
        </div>
        <Button
          onClick={() => setShowBooking(!showBooking)}
          className="bg-gradient-to-r from-yellow-500 to-orange-600 hover:from-yellow-600 hover:to-orange-700"
        >
          <Calendar className="h-4 w-4 mr-2" />
          Book Appointment
        </Button>
      </div>

      {showBooking && (
        <div className="bg-gradient-to-br from-yellow-900/30 to-orange-900/30 backdrop-blur-sm border border-yellow-500/30 rounded-xl p-6">
          <h3 className="text-xl font-semibold text-white mb-6">New Appointment</h3>

          <div className="space-y-6">
            {/* Specialization Selection */}
            <div>
              <label className="text-sm text-gray-400 mb-3 block">Select Specialization</label>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                {specializations.map((spec) => (
                  <div
                    key={spec.name}
                    onClick={() => setSelectedSpecialization(spec.name)}
                    className={`p-4 rounded-lg cursor-pointer transition-all border ${
                      selectedSpecialization === spec.name
                        ? 'bg-yellow-500/20 border-yellow-500 shadow-lg shadow-yellow-500/20'
                        : 'bg-slate-800/50 border-slate-700 hover:border-slate-600'
                    }`}
                  >
                    <div className="text-2xl mb-2">{spec.icon}</div>
                    <div className="text-sm font-medium text-white mb-1">{spec.name}</div>
                    <div className="text-xs text-gray-400">{spec.available} available</div>
                  </div>
                ))}
              </div>
            </div>

            {/* Consultation Type */}
            <div>
              <label className="text-sm text-gray-400 mb-3 block">Consultation Type</label>
              <div className="grid grid-cols-2 gap-4">
                <div
                  onClick={() => setConsultationType("video")}
                  className={`p-4 rounded-lg cursor-pointer transition-all border flex items-center gap-3 ${
                    consultationType === "video"
                      ? 'bg-blue-500/20 border-blue-500'
                      : 'bg-slate-800/50 border-slate-700 hover:border-slate-600'
                  }`}
                >
                  <Video className={`h-6 w-6 ${consultationType === "video" ? 'text-blue-400' : 'text-gray-400'}`} />
                  <div>
                    <div className="text-white font-medium">Video Call</div>
                    <div className="text-xs text-gray-400">Online consultation</div>
                  </div>
                </div>
                <div
                  onClick={() => setConsultationType("in-person")}
                  className={`p-4 rounded-lg cursor-pointer transition-all border flex items-center gap-3 ${
                    consultationType === "in-person"
                      ? 'bg-blue-500/20 border-blue-500'
                      : 'bg-slate-800/50 border-slate-700 hover:border-slate-600'
                  }`}
                >
                  <Building2 className={`h-6 w-6 ${consultationType === "in-person" ? 'text-blue-400' : 'text-gray-400'}`} />
                  <div>
                    <div className="text-white font-medium">In-Person</div>
                    <div className="text-xs text-gray-400">Hospital visit</div>
                  </div>
                </div>
              </div>
            </div>

            {/* Date and Time */}
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-sm text-gray-400 mb-2 block">Date</label>
                <Input
                  type="date"
                  value={appointmentDate}
                  onChange={(e) => setAppointmentDate(e.target.value)}
                  className="bg-slate-900/50 border-slate-700 text-white"
                />
              </div>
              <div>
                <label className="text-sm text-gray-400 mb-2 block">Time</label>
                <Input
                  type="time"
                  value={appointmentTime}
                  onChange={(e) => setAppointmentTime(e.target.value)}
                  className="bg-slate-900/50 border-slate-700 text-white"
                />
              </div>
            </div>

            {/* Reason */}
            <div>
              <label className="text-sm text-gray-400 mb-2 block">Reason for Visit</label>
              <Textarea
                value={reason}
                onChange={(e) => setReason(e.target.value)}
                placeholder="Brief description of your health concern..."
                className="bg-slate-900/50 border-slate-700 text-white placeholder:text-gray-500"
              />
            </div>

            {/* AI Suggestion */}
            {selectedSpecialization && (
              <div className="p-4 bg-blue-500/10 border border-blue-500/20 rounded-lg">
                <div className="flex items-center gap-2 mb-2">
                  <User className="h-4 w-4 text-blue-400" />
                  <span className="text-sm font-semibold text-blue-400">AI Doctor Recommendation</span>
                </div>
                <p className="text-sm text-gray-300">
                  Based on your symptoms and selected specialization, we recommend{' '}
                  <span className="text-white font-medium">{doctors[0].name}</span>{' '}
                  (Rating: {doctors[0].rating}⭐)
                </p>
              </div>
            )}

            <div className="flex gap-4">
              <Button
                onClick={handleBookAppointment}
                disabled={!selectedSpecialization || !appointmentDate || !appointmentTime}
                className="flex-1 bg-gradient-to-r from-yellow-500 to-orange-600 hover:from-yellow-600 hover:to-orange-700"
              >
                <CheckCircle className="h-4 w-4 mr-2" />
                Confirm Booking
              </Button>
              <Button
                onClick={() => setShowBooking(false)}
                variant="outline"
                className="border-slate-700 text-gray-300 hover:bg-slate-800"
              >
                Cancel
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* Appointments List */}
      <div>
        <h3 className="text-xl font-semibold text-white mb-4">Your Appointments</h3>
        <div className="space-y-4">
          {appointments.map((appointment) => (
            <div
              key={appointment.id}
              className="bg-slate-900/50 backdrop-blur-sm border border-slate-700/50 rounded-xl p-6 hover:border-yellow-500/50 transition-all"
            >
              <div className="flex items-start justify-between mb-4">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    <h4 className="text-lg font-semibold text-white">{appointment.id}</h4>
                    <Badge className={getStatusColor(appointment.status)}>
                      {appointment.status.toUpperCase()}
                    </Badge>
                    <Badge className={
                      appointment.type === "video"
                        ? "bg-blue-500/20 text-blue-400 border-blue-500/30"
                        : "bg-green-500/20 text-green-400 border-green-500/30"
                    }>
                      {appointment.type === "video" ? (
                        <><Video className="h-3 w-3 mr-1" />VIDEO</>
                      ) : (
                        <><Building2 className="h-3 w-3 mr-1" />IN-PERSON</>
                      )}
                    </Badge>
                  </div>
                  <p className="text-xl text-yellow-400 font-semibold mb-1">{appointment.doctorName}</p>
                  <p className="text-gray-400 mb-3">{appointment.specialization}</p>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4 mb-4">
                <div className="flex items-center gap-2 text-gray-300">
                  <Calendar className="h-4 w-4 text-gray-400" />
                  <span className="text-sm">{appointment.date}</span>
                </div>
                <div className="flex items-center gap-2 text-gray-300">
                  <Clock className="h-4 w-4 text-gray-400" />
                  <span className="text-sm">{appointment.time}</span>
                </div>
              </div>

              <div className="p-3 bg-slate-800/50 border border-slate-700/50 rounded-lg mb-4">
                <div className="flex items-start gap-2">
                  <FileText className="h-4 w-4 text-gray-400 mt-0.5" />
                  <div>
                    <p className="text-xs text-gray-400 mb-1">Reason for Visit</p>
                    <p className="text-sm text-white">{appointment.reason}</p>
                  </div>
                </div>
              </div>

              {appointment.type === "video" && appointment.status === "confirmed" && (
                <Button className="w-full bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700">
                  <Video className="h-4 w-4 mr-2" />
                  Join Video Call
                </Button>
              )}

              {appointment.prescription && (
                <div className="mt-4 p-3 bg-green-500/10 border border-green-500/20 rounded-lg">
                  <div className="flex items-center gap-2 mb-2">
                    <FileText className="h-4 w-4 text-green-400" />
                    <span className="text-sm font-semibold text-green-400">Digital Prescription Available</span>
                  </div>
                  <Button size="sm" variant="outline" className="border-green-500/30 text-green-400 hover:bg-green-500/20">
                    Download Prescription
                  </Button>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Available Doctors */}
      <div className="bg-slate-900/50 backdrop-blur-sm border border-slate-700/50 rounded-xl p-6">
        <h3 className="text-lg font-semibold text-white mb-4">Available Doctors (24/7)</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {doctors.map((doctor, index) => (
            <div key={index} className="p-4 bg-slate-800/50 border border-slate-700/50 rounded-lg">
              <div className="flex items-center gap-3 mb-2">
                <div className="h-10 w-10 rounded-full bg-gradient-to-br from-yellow-400 to-orange-500 flex items-center justify-center text-white font-semibold">
                  {doctor.name.split(' ')[1][0]}
                </div>
                <div>
                  <p className="text-white font-medium">{doctor.name}</p>
                  <p className="text-xs text-yellow-400">⭐ {doctor.rating}</p>
                </div>
              </div>
              <div className="flex items-center gap-2 text-xs text-gray-400">
                <Clock className="h-3 w-3" />
                <span>{doctor.available}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
