import { Activity, Users, Clock, TrendingUp, AlertCircle, CheckCircle, Brain, Zap } from "lucide-react";
import { LineChart, Line, BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from "recharts";
import { useEffect, useState } from "react";

const departmentData = [
  { name: "Laboratory", requests: 245, color: "#8b5cf6" },
  { name: "Billing", requests: 180, color: "#3b82f6" },
  { name: "Pharmacy", requests: 120, color: "#10b981" },
  { name: "Insurance", requests: 90, color: "#f59e0b" },
  { name: "Radiology", requests: 75, color: "#ef4444" },
];

export default function Dashboard() {
  const [healthScore, setHealthScore] = useState(87);
  const [liveData, setLiveData] = useState([
    { time: "10:00", requests: 45 },
    { time: "11:00", requests: 52 },
    { time: "12:00", requests: 48 },
    { time: "13:00", requests: 65 },
    { time: "14:00", requests: 58 },
    { time: "15:00", requests: 70 },
  ]);

  useEffect(() => {
    const interval = setInterval(() => {
      setLiveData(prev => {
        const newData = [...prev.slice(1)];
        const lastValue = prev[prev.length - 1].requests;
        const newValue = Math.max(30, Math.min(90, lastValue + Math.floor(Math.random() * 20) - 10));
        const currentTime = new Date();
        newData.push({
          time: `${currentTime.getHours()}:${String(currentTime.getMinutes()).padStart(2, '0')}`,
          requests: newValue
        });
        return newData;
      });

      setHealthScore(prev => {
        const change = Math.random() > 0.5 ? 1 : -1;
        return Math.max(70, Math.min(100, prev + change));
      });
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-3xl font-bold text-white mb-2">AI Command Center</h2>
        <p className="text-gray-400">Real-time hospital intelligence dashboard</p>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-gradient-to-br from-blue-500/20 to-blue-600/20 backdrop-blur-sm border border-blue-500/30 rounded-xl p-6 hover:scale-105 transition-transform">
          <div className="flex items-center justify-between mb-4">
            <div className="p-3 bg-blue-500/30 rounded-lg">
              <Activity className="h-6 w-6 text-blue-400" />
            </div>
            <span className="text-xs text-blue-400 font-semibold">LIVE</span>
          </div>
          <p className="text-gray-400 text-sm mb-1">Active Requests</p>
          <p className="text-3xl font-bold text-white">{liveData[liveData.length - 1].requests}</p>
          <p className="text-green-400 text-sm mt-2 flex items-center gap-1">
            <TrendingUp className="h-4 w-4" />
            +12% from last hour
          </p>
        </div>

        <div className="bg-gradient-to-br from-green-500/20 to-green-600/20 backdrop-blur-sm border border-green-500/30 rounded-xl p-6 hover:scale-105 transition-transform">
          <div className="flex items-center justify-between mb-4">
            <div className="p-3 bg-green-500/30 rounded-lg">
              <CheckCircle className="h-6 w-6 text-green-400" />
            </div>
            <span className="text-xs text-green-400 font-semibold">TODAY</span>
          </div>
          <p className="text-gray-400 text-sm mb-1">Resolved Cases</p>
          <p className="text-3xl font-bold text-white">234</p>
          <p className="text-green-400 text-sm mt-2 flex items-center gap-1">
            <TrendingUp className="h-4 w-4" />
            +8% efficiency
          </p>
        </div>

        <div className="bg-gradient-to-br from-orange-500/20 to-orange-600/20 backdrop-blur-sm border border-orange-500/30 rounded-xl p-6 hover:scale-105 transition-transform">
          <div className="flex items-center justify-between mb-4">
            <div className="p-3 bg-orange-500/30 rounded-lg">
              <Clock className="h-6 w-6 text-orange-400" />
            </div>
            <span className="text-xs text-orange-400 font-semibold">AVG</span>
          </div>
          <p className="text-gray-400 text-sm mb-1">Resolution Time</p>
          <p className="text-3xl font-bold text-white">2.4h</p>
          <p className="text-orange-400 text-sm mt-2 flex items-center gap-1">
            <TrendingUp className="h-4 w-4" />
            -15% faster
          </p>
        </div>

        <div className="bg-gradient-to-br from-purple-500/20 to-purple-600/20 backdrop-blur-sm border border-purple-500/30 rounded-xl p-6 hover:scale-105 transition-transform">
          <div className="flex items-center justify-between mb-4">
            <div className="p-3 bg-purple-500/30 rounded-lg">
              <Brain className="h-6 w-6 text-purple-400" />
            </div>
            <div className="flex items-center gap-1">
              <div className="h-2 w-2 bg-green-400 rounded-full animate-pulse"></div>
              <span className="text-xs text-purple-400 font-semibold">AI</span>
            </div>
          </div>
          <p className="text-gray-400 text-sm mb-1">Hospital Health Score</p>
          <p className="text-3xl font-bold text-white">{healthScore}/100</p>
          <div className="mt-2 h-2 bg-gray-700/50 rounded-full overflow-hidden">
            <div 
              className="h-full bg-gradient-to-r from-purple-500 to-pink-500 transition-all duration-500"
              style={{ width: `${healthScore}%` }}
            ></div>
          </div>
        </div>
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Live Request Flow */}
        <div className="bg-slate-900/50 backdrop-blur-sm border border-slate-700/50 rounded-xl p-6">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h3 className="text-xl font-bold text-white">Live Request Flow</h3>
              <p className="text-gray-400 text-sm">Real-time activity monitoring</p>
            </div>
            <div className="flex items-center gap-2 px-3 py-1 bg-green-500/20 border border-green-500/30 rounded-full">
              <div className="h-2 w-2 bg-green-400 rounded-full animate-pulse"></div>
              <span className="text-xs text-green-400 font-semibold">LIVE</span>
            </div>
          </div>
          <ResponsiveContainer width="100%" height={250}>
            <LineChart data={liveData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
              <XAxis dataKey="time" stroke="#9ca3af" />
              <YAxis stroke="#9ca3af" />
              <Tooltip 
                contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #475569', borderRadius: '8px' }}
                labelStyle={{ color: '#e5e7eb' }}
              />
              <Line 
                type="monotone" 
                dataKey="requests" 
                stroke="#8b5cf6" 
                strokeWidth={3}
                dot={{ fill: '#8b5cf6', r: 4 }}
                activeDot={{ r: 6 }}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>

        {/* Department Workload */}
        <div className="bg-slate-900/50 backdrop-blur-sm border border-slate-700/50 rounded-xl p-6">
          <div className="mb-6">
            <h3 className="text-xl font-bold text-white">Department Workload</h3>
            <p className="text-gray-400 text-sm">Distribution analysis</p>
          </div>
          <ResponsiveContainer width="100%" height={250}>
            <BarChart data={departmentData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
              <XAxis dataKey="name" stroke="#9ca3af" angle={-15} textAnchor="end" height={80} />
              <YAxis stroke="#9ca3af" />
              <Tooltip 
                contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #475569', borderRadius: '8px' }}
                labelStyle={{ color: '#e5e7eb' }}
              />
              <Bar dataKey="requests" radius={[8, 8, 0, 0]}>
                {departmentData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* AI Insights & Alerts */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* AI Insights */}
        <div className="lg:col-span-2 bg-slate-900/50 backdrop-blur-sm border border-slate-700/50 rounded-xl p-6">
          <div className="flex items-center gap-2 mb-6">
            <Brain className="h-6 w-6 text-purple-400" />
            <h3 className="text-xl font-bold text-white">AI-Generated Insights</h3>
          </div>
          <div className="space-y-4">
            <div className="flex gap-4 p-4 bg-blue-500/10 border border-blue-500/20 rounded-lg">
              <div className="p-2 bg-blue-500/20 rounded-lg h-fit">
                <TrendingUp className="h-5 w-5 text-blue-400" />
              </div>
              <div>
                <p className="text-white font-medium mb-1">Billing delays increased by 15% today</p>
                <p className="text-gray-400 text-sm">AI recommends allocating 2 additional staff members to billing department.</p>
                <span className="text-xs text-blue-400 mt-2 inline-block">Confidence: 94%</span>
              </div>
            </div>

            <div className="flex gap-4 p-4 bg-orange-500/10 border border-orange-500/20 rounded-lg">
              <div className="p-2 bg-orange-500/20 rounded-lg h-fit">
                <AlertCircle className="h-5 w-5 text-orange-400" />
              </div>
              <div>
                <p className="text-white font-medium mb-1">Predicted patient surge tomorrow at 2 PM</p>
                <p className="text-gray-400 text-sm">Historical pattern indicates 30% increase in lab requests expected.</p>
                <span className="text-xs text-orange-400 mt-2 inline-block">Confidence: 87%</span>
              </div>
            </div>

            <div className="flex gap-4 p-4 bg-green-500/10 border border-green-500/20 rounded-lg">
              <div className="p-2 bg-green-500/20 rounded-lg h-fit">
                <Zap className="h-5 w-5 text-green-400" />
              </div>
              <div>
                <p className="text-white font-medium mb-1">Lab department efficiency improved</p>
                <p className="text-gray-400 text-sm">Average processing time reduced from 3.2h to 2.8h this week.</p>
                <span className="text-xs text-green-400 mt-2 inline-block">Performance: +12.5%</span>
              </div>
            </div>
          </div>
        </div>

        {/* Request Distribution Pie */}
        <div className="bg-slate-900/50 backdrop-blur-sm border border-slate-700/50 rounded-xl p-6">
          <h3 className="text-xl font-bold text-white mb-6">Request Distribution</h3>
          <ResponsiveContainer width="100%" height={200}>
            <PieChart>
              <Pie
                data={departmentData}
                cx="50%"
                cy="50%"
                labelLine={false}
                outerRadius={80}
                fill="#8884d8"
                dataKey="requests"
              >
                {departmentData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip 
                contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #475569', borderRadius: '8px' }}
              />
            </PieChart>
          </ResponsiveContainer>
          <div className="mt-4 space-y-2">
            {departmentData.map((dept, index) => (
              <div key={index} className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="h-3 w-3 rounded-full" style={{ backgroundColor: dept.color }}></div>
                  <span className="text-sm text-gray-300">{dept.name}</span>
                </div>
                <span className="text-sm text-white font-medium">{dept.requests}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
