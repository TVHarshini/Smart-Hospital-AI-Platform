import { useState } from "react";
import { Ambulance, Phone, MapPin, Clock, AlertTriangle, Navigation, Users } from "lucide-react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Textarea } from "./ui/textarea";
import { Badge } from "./ui/badge";

interface EmergencyRequest {
  id: string;
  location: string;
  symptoms: string;
  severity: "critical" | "high" | "medium";
  ambulanceId: string;
  eta: string;
  status: "dispatched" | "en-route" | "arrived";
  driver: string;
  timestamp: string;
}

export default function Emergency() {
  const [emergencyActive, setEmergencyActive] = useState(false);
  const [location, setLocation] = useState("");
  const [symptoms, setSymptoms] = useState("");
  const [activeEmergency, setActiveEmergency] = useState<EmergencyRequest | null>(null);

  const handleEmergencyCall = () => {
    const emergency: EmergencyRequest = {
      id: `EMG-${Date.now()}`,
      location: location || "123 Main Street, City",
      symptoms,
      severity: "critical",
      ambulanceId: "AMB-" + Math.floor(Math.random() * 100),
      eta: Math.floor(Math.random() * 12) + 3 + " mins",
      status: "dispatched",
      driver: "Driver " + (Math.floor(Math.random() * 10) + 1),
      timestamp: new Date().toLocaleTimeString()
    };

    setActiveEmergency(emergency);
    setEmergencyActive(true);

    // Simulate status updates
    setTimeout(() => {
      setActiveEmergency(prev => prev ? { ...prev, status: "en-route" } : null);
    }, 3000);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-3xl font-bold text-white mb-2">Emergency Services</h2>
        <p className="text-gray-400">24/7 emergency ambulance dispatch with AI-powered routing</p>
      </div>

      {!emergencyActive ? (
        <>
          {/* Emergency Call Card */}
          <div className="bg-gradient-to-br from-red-900/40 to-orange-900/40 backdrop-blur-sm border-2 border-red-500/50 rounded-xl p-8">
            <div className="text-center mb-8">
              <div className="inline-flex items-center justify-center h-20 w-20 bg-red-500/20 rounded-full mb-4 animate-pulse">
                <Ambulance className="h-10 w-10 text-red-400" />
              </div>
              <h3 className="text-2xl font-bold text-white mb-2">Emergency Assistance</h3>
              <p className="text-gray-400">Press the button below for immediate ambulance dispatch</p>
            </div>

            <div className="space-y-4 mb-6 max-w-lg mx-auto">
              <div>
                <label className="text-sm text-gray-400 mb-2 block">Your Location</label>
                <div className="relative">
                  <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
                  <Input
                    value={location}
                    onChange={(e) => setLocation(e.target.value)}
                    placeholder="Enter location or use GPS..."
                    className="pl-10 bg-slate-900/50 border-slate-700 text-white"
                  />
                </div>
                <Button 
                  variant="outline" 
                  size="sm"
                  className="mt-2 border-slate-700 text-gray-300 hover:bg-slate-800"
                >
                  <Navigation className="h-3 w-3 mr-2" />
                  Detect Current Location
                </Button>
              </div>

              <div>
                <label className="text-sm text-gray-400 mb-2 block">Describe Emergency (Optional)</label>
                <Textarea
                  value={symptoms}
                  onChange={(e) => setSymptoms(e.target.value)}
                  placeholder="Brief description of the emergency..."
                  className="bg-slate-900/50 border-slate-700 text-white placeholder:text-gray-500"
                />
              </div>
            </div>

            <div className="text-center">
              <Button
                onClick={handleEmergencyCall}
                className="bg-gradient-to-r from-red-500 to-orange-600 hover:from-red-600 hover:to-orange-700 text-white px-12 py-6 text-lg font-bold shadow-lg shadow-red-500/50 animate-pulse"
              >
                <AlertTriangle className="h-6 w-6 mr-3" />
                CALL AMBULANCE NOW
              </Button>
              <p className="text-sm text-gray-400 mt-4">
                <Phone className="h-4 w-4 inline mr-1" />
                Or call emergency helpline: <span className="text-red-400 font-semibold">911</span>
              </p>
            </div>
          </div>

          {/* Info Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-slate-900/50 backdrop-blur-sm border border-slate-700/50 rounded-xl p-6">
              <div className="h-12 w-12 bg-red-500/20 rounded-lg flex items-center justify-center mb-4">
                <Clock className="h-6 w-6 text-red-400" />
              </div>
              <h4 className="text-white font-semibold mb-2">Fast Response</h4>
              <p className="text-sm text-gray-400">Average response time under 8 minutes</p>
            </div>

            <div className="bg-slate-900/50 backdrop-blur-sm border border-slate-700/50 rounded-xl p-6">
              <div className="h-12 w-12 bg-orange-500/20 rounded-lg flex items-center justify-center mb-4">
                <Navigation className="h-6 w-6 text-orange-400" />
              </div>
              <h4 className="text-white font-semibold mb-2">AI Routing</h4>
              <p className="text-sm text-gray-400">Smart dispatch finds nearest ambulance</p>
            </div>

            <div className="bg-slate-900/50 backdrop-blur-sm border border-slate-700/50 rounded-xl p-6">
              <div className="h-12 w-12 bg-yellow-500/20 rounded-lg flex items-center justify-center mb-4">
                <Users className="h-6 w-6 text-yellow-400" />
              </div>
              <h4 className="text-white font-semibold mb-2">Trained Paramedics</h4>
              <p className="text-sm text-gray-400">Experienced medical professionals onboard</p>
            </div>
          </div>
        </>
      ) : (
        /* Active Emergency */
        <div className="space-y-6">
          {/* Status Card */}
          <div className="bg-gradient-to-br from-red-900/40 to-orange-900/40 backdrop-blur-sm border-2 border-red-500/50 rounded-xl p-8">
            <div className="flex items-center justify-between mb-6">
              <div>
                <Badge className="bg-red-500/20 text-red-400 border-red-500/30 mb-3 animate-pulse">
                  EMERGENCY ACTIVE
                </Badge>
                <h3 className="text-2xl font-bold text-white mb-1">{activeEmergency?.id}</h3>
                <p className="text-gray-400">Emergency request in progress</p>
              </div>
              <div className="text-center">
                <div className="h-20 w-20 bg-red-500/20 rounded-full flex items-center justify-center animate-pulse mb-2">
                  <Ambulance className="h-10 w-10 text-red-400" />
                </div>
                <Badge className={`${
                  activeEmergency?.status === "dispatched" 
                    ? "bg-orange-500/20 text-orange-400 border-orange-500/30"
                    : activeEmergency?.status === "en-route"
                    ? "bg-yellow-500/20 text-yellow-400 border-yellow-500/30"
                    : "bg-green-500/20 text-green-400 border-green-500/30"
                }`}>
                  {activeEmergency?.status.toUpperCase().replace("-", " ")}
                </Badge>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
              <div className="space-y-4">
                <div className="flex items-start gap-3">
                  <MapPin className="h-5 w-5 text-gray-400 mt-0.5" />
                  <div>
                    <p className="text-sm text-gray-400">Location</p>
                    <p className="text-white font-medium">{activeEmergency?.location}</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <Ambulance className="h-5 w-5 text-gray-400 mt-0.5" />
                  <div>
                    <p className="text-sm text-gray-400">Ambulance ID</p>
                    <p className="text-white font-medium">{activeEmergency?.ambulanceId}</p>
                  </div>
                </div>
              </div>
              <div className="space-y-4">
                <div className="flex items-start gap-3">
                  <Clock className="h-5 w-5 text-gray-400 mt-0.5" />
                  <div>
                    <p className="text-sm text-gray-400">Estimated Arrival</p>
                    <p className="text-2xl text-red-400 font-bold">{activeEmergency?.eta}</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <Users className="h-5 w-5 text-gray-400 mt-0.5" />
                  <div>
                    <p className="text-sm text-gray-400">Driver</p>
                    <p className="text-white font-medium">{activeEmergency?.driver}</p>
                  </div>
                </div>
              </div>
            </div>

            {activeEmergency?.symptoms && (
              <div className="p-4 bg-slate-900/50 border border-slate-700/50 rounded-lg mb-6">
                <p className="text-sm text-gray-400 mb-1">Reported Symptoms</p>
                <p className="text-white">{activeEmergency.symptoms}</p>
              </div>
            )}

            <div className="flex gap-4">
              <Button className="flex-1 bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700">
                <Phone className="h-4 w-4 mr-2" />
                Call Ambulance
              </Button>
              <Button className="flex-1 bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700">
                <Navigation className="h-4 w-4 mr-2" />
                Track Live Location
              </Button>
            </div>
          </div>

          {/* Timeline */}
          <div className="bg-slate-900/50 backdrop-blur-sm border border-slate-700/50 rounded-xl p-6">
            <h4 className="text-lg font-semibold text-white mb-4">Emergency Timeline</h4>
            <div className="space-y-4">
              <div className="flex items-start gap-4">
                <div className="h-8 w-8 rounded-full bg-green-500/20 border-2 border-green-500 flex items-center justify-center flex-shrink-0">
                  <div className="h-2 w-2 rounded-full bg-green-400"></div>
                </div>
                <div>
                  <p className="text-white font-medium">Emergency request received</p>
                  <p className="text-sm text-gray-400">{activeEmergency?.timestamp}</p>
                </div>
              </div>
              <div className="flex items-start gap-4">
                <div className={`h-8 w-8 rounded-full flex items-center justify-center flex-shrink-0 ${
                  activeEmergency?.status === "dispatched" || activeEmergency?.status === "en-route"
                    ? "bg-green-500/20 border-2 border-green-500"
                    : "bg-slate-800/50 border-2 border-slate-600"
                }`}>
                  {activeEmergency?.status === "dispatched" || activeEmergency?.status === "en-route" ? (
                    <div className="h-2 w-2 rounded-full bg-green-400"></div>
                  ) : (
                    <div className="h-2 w-2 rounded-full bg-slate-600"></div>
                  )}
                </div>
                <div>
                  <p className={`font-medium ${
                    activeEmergency?.status === "dispatched" || activeEmergency?.status === "en-route"
                      ? "text-white"
                      : "text-gray-500"
                  }`}>
                    Ambulance dispatched
                  </p>
                  <p className="text-sm text-gray-400">AI selected nearest ambulance</p>
                </div>
              </div>
              <div className="flex items-start gap-4">
                <div className={`h-8 w-8 rounded-full flex items-center justify-center flex-shrink-0 ${
                  activeEmergency?.status === "en-route"
                    ? "bg-yellow-500/20 border-2 border-yellow-500 animate-pulse"
                    : "bg-slate-800/50 border-2 border-slate-600"
                }`}>
                  {activeEmergency?.status === "en-route" ? (
                    <Ambulance className="h-3 w-3 text-yellow-400" />
                  ) : (
                    <div className="h-2 w-2 rounded-full bg-slate-600"></div>
                  )}
                </div>
                <div>
                  <p className={`font-medium ${
                    activeEmergency?.status === "en-route" ? "text-white" : "text-gray-500"
                  }`}>
                    En route to location
                  </p>
                  <p className="text-sm text-gray-400">ETA: {activeEmergency?.eta}</p>
                </div>
              </div>
            </div>
          </div>

          <Button
            onClick={() => {
              setEmergencyActive(false);
              setActiveEmergency(null);
              setLocation("");
              setSymptoms("");
            }}
            variant="outline"
            className="w-full border-slate-700 text-gray-300 hover:bg-slate-800"
          >
            Cancel Emergency
          </Button>
        </div>
      )}
    </div>
  );
}
