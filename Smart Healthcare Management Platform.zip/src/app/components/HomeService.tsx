import { useState } from "react";
import { Home, MapPin, Calendar, Clock, User, CheckCircle, Navigation } from "lucide-react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Badge } from "./ui/badge";

interface HomeServiceRequest {
  id: string;
  service: string;
  location: string;
  date: string;
  time: string;
  status: "scheduled" | "en-route" | "completed";
  technician: string;
  eta: string;
}

export default function HomeService() {
  const [activeBookings, setActiveBookings] = useState<HomeServiceRequest[]>([
    {
      id: "HS-001",
      service: "Blood Test",
      location: "123 Main St, Apartment 4B",
      date: "2026-03-01",
      time: "10:00 AM",
      status: "en-route",
      technician: "Dr. Kumar",
      eta: "15 mins"
    },
    {
      id: "HS-002",
      service: "ECG Test",
      location: "456 Park Avenue, Floor 2",
      date: "2026-03-02",
      time: "2:00 PM",
      status: "scheduled",
      technician: "Tech. Priya",
      eta: "Tomorrow"
    }
  ]);

  const [selectedService, setSelectedService] = useState("");
  const [location, setLocation] = useState("");
  const [selectedDate, setSelectedDate] = useState("");
  const [selectedTime, setSelectedTime] = useState("");

  const services = [
    { name: "Blood Test", icon: "🩸", duration: "15 mins" },
    { name: "ECG Test", icon: "💓", duration: "20 mins" },
    { name: "BP Check", icon: "🩺", duration: "10 mins" },
    { name: "Full Body Checkup", icon: "🏥", duration: "45 mins" },
    { name: "Vaccination", icon: "💉", duration: "10 mins" },
    { name: "Sample Collection", icon: "🧪", duration: "15 mins" }
  ];

  const handleBookService = () => {
    if (!selectedService || !location || !selectedDate || !selectedTime) return;

    const newBooking: HomeServiceRequest = {
      id: `HS-${String(activeBookings.length + 1).padStart(3, '0')}`,
      service: selectedService,
      location,
      date: selectedDate,
      time: selectedTime,
      status: "scheduled",
      technician: "Auto-assigned",
      eta: "Scheduled"
    };

    setActiveBookings([newBooking, ...activeBookings]);
    
    // Reset form
    setSelectedService("");
    setLocation("");
    setSelectedDate("");
    setSelectedTime("");
  };

  const getStatusColor = (status: string) => {
    const colors = {
      scheduled: "bg-blue-500/20 text-blue-400 border-blue-500/30",
      "en-route": "bg-green-500/20 text-green-400 border-green-500/30 animate-pulse",
      completed: "bg-gray-500/20 text-gray-400 border-gray-500/30"
    };
    return colors[status as keyof typeof colors];
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-3xl font-bold text-white mb-2">Home Healthcare Service</h2>
        <p className="text-gray-400">Book diagnostic tests and healthcare services at home</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Book New Service */}
        <div className="bg-gradient-to-br from-green-900/30 to-teal-900/30 backdrop-blur-sm border border-green-500/30 rounded-xl p-6">
          <div className="flex items-center gap-2 mb-6">
            <Home className="h-6 w-6 text-green-400" />
            <h3 className="text-xl font-semibold text-white">Book Home Service</h3>
          </div>

          {/* Service Selection */}
          <div className="space-y-4 mb-6">
            <div>
              <label className="text-sm text-gray-400 mb-2 block">Select Service</label>
              <div className="grid grid-cols-2 gap-3">
                {services.map((service) => (
                  <div
                    key={service.name}
                    onClick={() => setSelectedService(service.name)}
                    className={`p-4 rounded-lg cursor-pointer transition-all border ${
                      selectedService === service.name
                        ? 'bg-green-500/20 border-green-500 shadow-lg shadow-green-500/20'
                        : 'bg-slate-800/50 border-slate-700 hover:border-slate-600'
                    }`}
                  >
                    <div className="text-2xl mb-2">{service.icon}</div>
                    <div className="text-sm font-medium text-white">{service.name}</div>
                    <div className="text-xs text-gray-400">{service.duration}</div>
                  </div>
                ))}
              </div>
            </div>

            {/* Location */}
            <div>
              <label className="text-sm text-gray-400 mb-2 block">Service Location</label>
              <div className="relative">
                <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
                <Input
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                  placeholder="Enter your address..."
                  className="pl-10 bg-slate-900/50 border-slate-700 text-white"
                />
              </div>
              <Button 
                variant="outline" 
                size="sm"
                className="mt-2 border-slate-700 text-gray-300 hover:bg-slate-800"
              >
                <Navigation className="h-3 w-3 mr-2" />
                Use Current Location
              </Button>
            </div>

            {/* Date and Time */}
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-sm text-gray-400 mb-2 block">Date</label>
                <div className="relative">
                  <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
                  <Input
                    type="date"
                    value={selectedDate}
                    onChange={(e) => setSelectedDate(e.target.value)}
                    className="pl-10 bg-slate-900/50 border-slate-700 text-white"
                  />
                </div>
              </div>
              <div>
                <label className="text-sm text-gray-400 mb-2 block">Time</label>
                <div className="relative">
                  <Clock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
                  <Input
                    type="time"
                    value={selectedTime}
                    onChange={(e) => setSelectedTime(e.target.value)}
                    className="pl-10 bg-slate-900/50 border-slate-700 text-white"
                  />
                </div>
              </div>
            </div>
          </div>

          <Button 
            onClick={handleBookService}
            disabled={!selectedService || !location || !selectedDate || !selectedTime}
            className="w-full bg-gradient-to-r from-green-500 to-teal-600 hover:from-green-600 hover:to-teal-700"
          >
            <CheckCircle className="h-4 w-4 mr-2" />
            Book Service
          </Button>

          {/* AI Suggestion */}
          <div className="mt-4 p-3 bg-blue-500/10 border border-blue-500/20 rounded-lg">
            <p className="text-xs text-blue-400">
              💡 AI will assign the nearest available technician based on your location and selected time.
            </p>
          </div>
        </div>

        {/* Active Bookings */}
        <div className="space-y-4">
          <h3 className="text-xl font-semibold text-white">Active Bookings</h3>
          
          {activeBookings.length === 0 ? (
            <div className="bg-slate-900/50 backdrop-blur-sm border border-slate-700/50 rounded-xl p-8 text-center">
              <Home className="h-12 w-12 text-gray-600 mx-auto mb-4" />
              <p className="text-gray-400">No active bookings</p>
            </div>
          ) : (
            activeBookings.map((booking) => (
              <div
                key={booking.id}
                className="bg-slate-900/50 backdrop-blur-sm border border-slate-700/50 rounded-xl p-6 hover:border-green-500/50 transition-all"
              >
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <div className="flex items-center gap-2 mb-2">
                      <h4 className="text-lg font-semibold text-white">{booking.id}</h4>
                      <Badge className={getStatusColor(booking.status)}>
                        {booking.status === "en-route" ? "EN ROUTE" : booking.status.toUpperCase()}
                      </Badge>
                    </div>
                    <p className="text-xl text-green-400 font-semibold mb-2">{booking.service}</p>
                  </div>
                </div>

                <div className="space-y-3 text-sm">
                  <div className="flex items-start gap-2 text-gray-300">
                    <MapPin className="h-4 w-4 text-gray-400 mt-0.5" />
                    <span>{booking.location}</span>
                  </div>
                  <div className="flex items-center gap-2 text-gray-300">
                    <Calendar className="h-4 w-4 text-gray-400" />
                    <span>{booking.date} at {booking.time}</span>
                  </div>
                  <div className="flex items-center gap-2 text-gray-300">
                    <User className="h-4 w-4 text-gray-400" />
                    <span>{booking.technician}</span>
                  </div>
                  {booking.status === "en-route" && (
                    <div className="flex items-center gap-2">
                      <Clock className="h-4 w-4 text-green-400" />
                      <span className="text-green-400 font-medium">ETA: {booking.eta}</span>
                    </div>
                  )}
                </div>

                {booking.status === "en-route" && (
                  <div className="mt-4 p-3 bg-green-500/10 border border-green-500/20 rounded-lg">
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-green-400">Technician is on the way</span>
                      <Button size="sm" variant="outline" className="border-green-500/30 text-green-400 hover:bg-green-500/20">
                        <Navigation className="h-3 w-3 mr-2" />
                        Track
                      </Button>
                    </div>
                  </div>
                )}
              </div>
            ))
          )}
        </div>
      </div>

      {/* Features */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-slate-900/50 backdrop-blur-sm border border-slate-700/50 rounded-xl p-6">
          <div className="h-12 w-12 bg-green-500/20 rounded-lg flex items-center justify-center mb-4">
            <MapPin className="h-6 w-6 text-green-400" />
          </div>
          <h4 className="text-white font-semibold mb-2">GPS Tracking</h4>
          <p className="text-sm text-gray-400">Real-time location tracking of technicians</p>
        </div>

        <div className="bg-slate-900/50 backdrop-blur-sm border border-slate-700/50 rounded-xl p-6">
          <div className="h-12 w-12 bg-blue-500/20 rounded-lg flex items-center justify-center mb-4">
            <Clock className="h-6 w-6 text-blue-400" />
          </div>
          <h4 className="text-white font-semibold mb-2">24/7 Service</h4>
          <p className="text-sm text-gray-400">Book services anytime, any day</p>
        </div>

        <div className="bg-slate-900/50 backdrop-blur-sm border border-slate-700/50 rounded-xl p-6">
          <div className="h-12 w-12 bg-purple-500/20 rounded-lg flex items-center justify-center mb-4">
            <User className="h-6 w-6 text-purple-400" />
          </div>
          <h4 className="text-white font-semibold mb-2">Certified Professionals</h4>
          <p className="text-sm text-gray-400">Experienced and verified technicians</p>
        </div>
      </div>
    </div>
  );
}
