import { useState } from "react";
import { Send, Search, Filter, Clock, CheckCircle2, AlertCircle, Loader, ChevronRight, Brain } from "lucide-react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Textarea } from "./ui/textarea";
import { Badge } from "./ui/badge";
import { Progress } from "./ui/progress";

type RequestStatus = "submitted" | "classified" | "routed" | "processing" | "review" | "completed";

interface Request {
  id: string;
  description: string;
  category: string;
  priority: "low" | "medium" | "high" | "critical";
  status: RequestStatus;
  progress: number;
  department: string;
  aiConfidence: number;
  estimatedTime: string;
  createdAt: string;
}

const statusSteps: Record<RequestStatus, { label: string; order: number }> = {
  submitted: { label: "Submitted", order: 0 },
  classified: { label: "AI Classified", order: 1 },
  routed: { label: "Routed", order: 2 },
  processing: { label: "Processing", order: 3 },
  review: { label: "Under Review", order: 4 },
  completed: { label: "Completed", order: 5 },
};

export default function Requests() {
  const [requests, setRequests] = useState<Request[]>([
    {
      id: "REQ-2401",
      description: "Need duplicate lab report for blood test",
      category: "Lab Report",
      priority: "medium",
      status: "processing",
      progress: 65,
      department: "Laboratory",
      aiConfidence: 94,
      estimatedTime: "1.2 hours",
      createdAt: "2 hours ago"
    },
    {
      id: "REQ-2402",
      description: "Billing discrepancy in invoice",
      category: "Billing",
      priority: "high",
      status: "review",
      progress: 80,
      department: "Billing",
      aiConfidence: 91,
      estimatedTime: "45 mins",
      createdAt: "1 hour ago"
    },
    {
      id: "REQ-2403",
      description: "Insurance claim verification needed",
      category: "Insurance",
      priority: "low",
      status: "routed",
      progress: 35,
      department: "Insurance",
      aiConfidence: 88,
      estimatedTime: "3.5 hours",
      createdAt: "30 mins ago"
    },
  ]);

  const [newRequest, setNewRequest] = useState("");
  const [selectedRequest, setSelectedRequest] = useState<Request | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmitRequest = async () => {
    if (!newRequest.trim()) return;

    setIsSubmitting(true);
    
    // Simulate AI classification
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    const categories = ["Lab Report", "Billing", "Pharmacy", "Insurance", "Appointment"];
    const departments = ["Laboratory", "Billing", "Pharmacy", "Insurance", "Front Desk"];
    const priorities: ("low" | "medium" | "high" | "critical")[] = ["low", "medium", "high"];
    
    const randomCategory = categories[Math.floor(Math.random() * categories.length)];
    const randomDepartment = departments[Math.floor(Math.random() * departments.length)];
    const randomPriority = priorities[Math.floor(Math.random() * priorities.length)];
    
    const request: Request = {
      id: `REQ-${2400 + requests.length + 1}`,
      description: newRequest,
      category: randomCategory,
      priority: randomPriority,
      status: "classified",
      progress: 20,
      department: randomDepartment,
      aiConfidence: Math.floor(Math.random() * 15) + 85,
      estimatedTime: `${Math.floor(Math.random() * 4) + 1}.${Math.floor(Math.random() * 9)} hours`,
      createdAt: "Just now"
    };

    setRequests([request, ...requests]);
    setNewRequest("");
    setIsSubmitting(false);

    // Auto-progress the request
    setTimeout(() => {
      setRequests(prev => prev.map(r => 
        r.id === request.id ? { ...r, status: "routed", progress: 40 } : r
      ));
    }, 2000);
  };

  const getPriorityColor = (priority: string) => {
    const colors = {
      low: "bg-green-500/20 text-green-400 border-green-500/30",
      medium: "bg-yellow-500/20 text-yellow-400 border-yellow-500/30",
      high: "bg-orange-500/20 text-orange-400 border-orange-500/30",
      critical: "bg-red-500/20 text-red-400 border-red-500/30 animate-pulse"
    };
    return colors[priority as keyof typeof colors];
  };

  const getStatusColor = (status: RequestStatus) => {
    const colors = {
      submitted: "text-gray-400",
      classified: "text-blue-400",
      routed: "text-purple-400",
      processing: "text-yellow-400",
      review: "text-orange-400",
      completed: "text-green-400"
    };
    return colors[status];
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-3xl font-bold text-white mb-2">Request Management</h2>
        <p className="text-gray-400">AI-powered request processing and tracking</p>
      </div>

      {/* Submit New Request */}
      <div className="bg-gradient-to-br from-blue-900/30 to-purple-900/30 backdrop-blur-sm border border-blue-500/30 rounded-xl p-6">
        <div className="flex items-center gap-2 mb-4">
          <Brain className="h-5 w-5 text-blue-400" />
          <h3 className="text-lg font-semibold text-white">Submit New Request</h3>
          <Badge className="ml-auto bg-blue-500/20 text-blue-400 border-blue-500/30">AI-Powered</Badge>
        </div>
        <Textarea
          placeholder="Describe your request... (AI will automatically classify and route)"
          value={newRequest}
          onChange={(e) => setNewRequest(e.target.value)}
          className="bg-slate-900/50 border-slate-700 text-white placeholder:text-gray-500 mb-4 min-h-24"
        />
        <Button 
          onClick={handleSubmitRequest}
          disabled={isSubmitting || !newRequest.trim()}
          className="bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700"
        >
          {isSubmitting ? (
            <>
              <Loader className="h-4 w-4 mr-2 animate-spin" />
              AI Processing...
            </>
          ) : (
            <>
              <Send className="h-4 w-4 mr-2" />
              Submit Request
            </>
          )}
        </Button>
      </div>

      {/* Filters */}
      <div className="flex gap-4">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
          <Input 
            placeholder="Search requests..." 
            className="pl-10 bg-slate-900/50 border-slate-700 text-white"
          />
        </div>
        <Button variant="outline" className="border-slate-700 text-gray-300 hover:bg-slate-800">
          <Filter className="h-4 w-4 mr-2" />
          Filter
        </Button>
      </div>

      {/* Requests List */}
      <div className="space-y-4">
        {requests.map((request) => (
          <div
            key={request.id}
            onClick={() => setSelectedRequest(selectedRequest?.id === request.id ? null : request)}
            className="bg-slate-900/50 backdrop-blur-sm border border-slate-700/50 rounded-xl p-6 hover:border-blue-500/50 transition-all cursor-pointer"
          >
            <div className="flex items-start justify-between mb-4">
              <div className="flex-1">
                <div className="flex items-center gap-3 mb-2">
                  <h4 className="text-lg font-semibold text-white">{request.id}</h4>
                  <Badge className={getPriorityColor(request.priority)}>
                    {request.priority.toUpperCase()}
                  </Badge>
                  <Badge className="bg-purple-500/20 text-purple-400 border-purple-500/30">
                    {request.category}
                  </Badge>
                  <Badge className="bg-slate-700/50 text-gray-300 border-slate-600/30">
                    {request.department}
                  </Badge>
                </div>
                <p className="text-gray-300 mb-3">{request.description}</p>
                
                {/* Progress */}
                <div className="mb-4">
                  <div className="flex items-center justify-between mb-2">
                    <span className={`text-sm font-medium ${getStatusColor(request.status)}`}>
                      {statusSteps[request.status].label}
                    </span>
                    <span className="text-sm text-gray-400">{request.progress}% Complete</span>
                  </div>
                  <Progress value={request.progress} className="h-2" />
                </div>

                {/* Info Row */}
                <div className="flex items-center gap-6 text-sm text-gray-400">
                  <div className="flex items-center gap-1">
                    <Clock className="h-4 w-4" />
                    ETA: {request.estimatedTime}
                  </div>
                  <div className="flex items-center gap-1">
                    <Brain className="h-4 w-4 text-purple-400" />
                    AI Confidence: {request.aiConfidence}%
                  </div>
                  <div className="text-gray-500">{request.createdAt}</div>
                </div>
              </div>

              <ChevronRight 
                className={`h-5 w-5 text-gray-400 transition-transform ${
                  selectedRequest?.id === request.id ? 'rotate-90' : ''
                }`} 
              />
            </div>

            {/* Expanded Details */}
            {selectedRequest?.id === request.id && (
              <div className="mt-6 pt-6 border-t border-slate-700/50">
                <h5 className="text-white font-semibold mb-4">Processing Timeline</h5>
                <div className="space-y-3">
                  {Object.entries(statusSteps).map(([key, step]) => {
                    const currentOrder = statusSteps[request.status].order;
                    const isCompleted = step.order <= currentOrder;
                    const isCurrent = step.order === currentOrder;
                    
                    return (
                      <div key={key} className="flex items-center gap-3">
                        <div className={`h-8 w-8 rounded-full flex items-center justify-center border-2 ${
                          isCompleted 
                            ? 'bg-blue-500/20 border-blue-500' 
                            : 'bg-slate-800/50 border-slate-600'
                        }`}>
                          {isCompleted ? (
                            isCurrent ? (
                              <Loader className="h-4 w-4 text-blue-400 animate-spin" />
                            ) : (
                              <CheckCircle2 className="h-4 w-4 text-blue-400" />
                            )
                          ) : (
                            <div className="h-2 w-2 rounded-full bg-slate-600"></div>
                          )}
                        </div>
                        <div className="flex-1">
                          <p className={`font-medium ${
                            isCompleted ? 'text-white' : 'text-gray-500'
                          }`}>
                            {step.label}
                          </p>
                          {isCurrent && (
                            <p className="text-sm text-blue-400">In progress...</p>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>

                {/* AI Analysis */}
                <div className="mt-6 p-4 bg-purple-500/10 border border-purple-500/20 rounded-lg">
                  <div className="flex items-center gap-2 mb-2">
                    <Brain className="h-4 w-4 text-purple-400" />
                    <h6 className="text-sm font-semibold text-purple-400">AI Analysis</h6>
                  </div>
                  <p className="text-sm text-gray-300">
                    Request automatically classified as "{request.category}" with {request.aiConfidence}% confidence. 
                    Routed to {request.department} based on workload optimization and historical pattern analysis.
                  </p>
                </div>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
