import { Outlet, Link, useLocation } from "react-router";
import { Activity, Home, FileText, Ambulance, Calendar, Heart, BarChart3, Bell, Moon, Sun } from "lucide-react";
import { useState } from "react";

export default function Root() {
  const location = useLocation();
  const [darkMode, setDarkMode] = useState(true);

  const isActive = (path: string) => {
    if (path === "/" && location.pathname === "/") return true;
    if (path !== "/" && location.pathname.startsWith(path)) return true;
    return false;
  };

  return (
    <div className={`min-h-screen ${darkMode ? 'bg-gradient-to-br from-slate-900 via-blue-900 to-purple-900' : 'bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50'}`}>
      {/* Top Bar */}
      <div className={`${darkMode ? 'bg-slate-900/80 border-slate-700/50' : 'bg-white/80 border-gray-200'} backdrop-blur-lg border-b sticky top-0 z-50`}>
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg">
              <Activity className="h-6 w-6 text-white" />
            </div>
            <div>
              <h1 className={`text-xl font-bold ${darkMode ? 'text-white' : 'text-gray-900'}`}>
                Smart Hospital AI Platform
              </h1>
              <p className={`text-xs ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                AI-Driven Healthcare Governance System
              </p>
            </div>
          </div>
          
          <div className="flex items-center gap-4">
            <button className={`relative p-2 ${darkMode ? 'hover:bg-slate-800' : 'hover:bg-gray-100'} rounded-lg transition-colors`}>
              <Bell className={`h-5 w-5 ${darkMode ? 'text-gray-300' : 'text-gray-600'}`} />
              <span className="absolute top-1 right-1 h-2 w-2 bg-red-500 rounded-full animate-pulse"></span>
            </button>
            
            <button 
              onClick={() => setDarkMode(!darkMode)}
              className={`p-2 ${darkMode ? 'hover:bg-slate-800' : 'hover:bg-gray-100'} rounded-lg transition-colors`}
            >
              {darkMode ? 
                <Sun className="h-5 w-5 text-yellow-400" /> : 
                <Moon className="h-5 w-5 text-blue-600" />
              }
            </button>
            
            <div className={`flex items-center gap-2 px-3 py-2 ${darkMode ? 'bg-slate-800' : 'bg-gray-100'} rounded-lg`}>
              <div className="h-8 w-8 rounded-full bg-gradient-to-br from-green-400 to-blue-500 flex items-center justify-center text-white font-semibold text-sm">
                A
              </div>
              <span className={`text-sm font-medium ${darkMode ? 'text-white' : 'text-gray-900'}`}>Admin</span>
            </div>
          </div>
        </div>
      </div>

      <div className="flex max-w-7xl mx-auto">
        {/* Sidebar */}
        <aside className={`w-64 min-h-[calc(100vh-80px)] p-6 ${darkMode ? 'bg-slate-900/50' : 'bg-white/50'} backdrop-blur-sm border-r ${darkMode ? 'border-slate-700/50' : 'border-gray-200'}`}>
          <nav className="space-y-2">
            <Link
              to="/"
              className={`flex items-center gap-3 px-4 py-3 rounded-lg transition-all ${
                isActive("/") && location.pathname === "/"
                  ? `${darkMode ? 'bg-gradient-to-r from-blue-500 to-purple-600 text-white shadow-lg shadow-blue-500/50' : 'bg-gradient-to-r from-blue-500 to-purple-600 text-white'}`
                  : `${darkMode ? 'text-gray-300 hover:bg-slate-800' : 'text-gray-600 hover:bg-gray-100'}`
              }`}
            >
              <Home className="h-5 w-5" />
              <span className="font-medium">Dashboard</span>
            </Link>

            <Link
              to="/requests"
              className={`flex items-center gap-3 px-4 py-3 rounded-lg transition-all ${
                isActive("/requests")
                  ? `${darkMode ? 'bg-gradient-to-r from-blue-500 to-purple-600 text-white shadow-lg shadow-blue-500/50' : 'bg-gradient-to-r from-blue-500 to-purple-600 text-white'}`
                  : `${darkMode ? 'text-gray-300 hover:bg-slate-800' : 'text-gray-600 hover:bg-gray-100'}`
              }`}
            >
              <FileText className="h-5 w-5" />
              <span className="font-medium">Requests</span>
            </Link>

            <Link
              to="/home-service"
              className={`flex items-center gap-3 px-4 py-3 rounded-lg transition-all ${
                isActive("/home-service")
                  ? `${darkMode ? 'bg-gradient-to-r from-green-500 to-teal-600 text-white shadow-lg shadow-green-500/50' : 'bg-gradient-to-r from-green-500 to-teal-600 text-white'}`
                  : `${darkMode ? 'text-gray-300 hover:bg-slate-800' : 'text-gray-600 hover:bg-gray-100'}`
              }`}
            >
              <Home className="h-5 w-5" />
              <span className="font-medium">Home Service</span>
            </Link>

            <Link
              to="/emergency"
              className={`flex items-center gap-3 px-4 py-3 rounded-lg transition-all ${
                isActive("/emergency")
                  ? `${darkMode ? 'bg-gradient-to-r from-red-500 to-orange-600 text-white shadow-lg shadow-red-500/50' : 'bg-gradient-to-r from-red-500 to-orange-600 text-white'}`
                  : `${darkMode ? 'text-gray-300 hover:bg-slate-800' : 'text-gray-600 hover:bg-gray-100'}`
              }`}
            >
              <Ambulance className="h-5 w-5" />
              <span className="font-medium">Emergency</span>
            </Link>

            <Link
              to="/appointments"
              className={`flex items-center gap-3 px-4 py-3 rounded-lg transition-all ${
                isActive("/appointments")
                  ? `${darkMode ? 'bg-gradient-to-r from-yellow-500 to-orange-600 text-white shadow-lg shadow-yellow-500/50' : 'bg-gradient-to-r from-yellow-500 to-orange-600 text-white'}`
                  : `${darkMode ? 'text-gray-300 hover:bg-slate-800' : 'text-gray-600 hover:bg-gray-100'}`
              }`}
            >
              <Calendar className="h-5 w-5" />
              <span className="font-medium">Appointments</span>
            </Link>

            <Link
              to="/vital-monitoring"
              className={`flex items-center gap-3 px-4 py-3 rounded-lg transition-all ${
                isActive("/vital-monitoring")
                  ? `${darkMode ? 'bg-gradient-to-r from-pink-500 to-rose-600 text-white shadow-lg shadow-pink-500/50' : 'bg-gradient-to-r from-pink-500 to-rose-600 text-white'}`
                  : `${darkMode ? 'text-gray-300 hover:bg-slate-800' : 'text-gray-600 hover:bg-gray-100'}`
              }`}
            >
              <Heart className="h-5 w-5" />
              <span className="font-medium">Vital Monitoring</span>
            </Link>

            <Link
              to="/analytics"
              className={`flex items-center gap-3 px-4 py-3 rounded-lg transition-all ${
                isActive("/analytics")
                  ? `${darkMode ? 'bg-gradient-to-r from-indigo-500 to-purple-600 text-white shadow-lg shadow-indigo-500/50' : 'bg-gradient-to-r from-indigo-500 to-purple-600 text-white'}`
                  : `${darkMode ? 'text-gray-300 hover:bg-slate-800' : 'text-gray-600 hover:bg-gray-100'}`
              }`}
            >
              <BarChart3 className="h-5 w-5" />
              <span className="font-medium">Analytics</span>
            </Link>
          </nav>

          {/* AI Status Card */}
          <div className={`mt-8 p-4 ${darkMode ? 'bg-gradient-to-br from-blue-900/50 to-purple-900/50 border-blue-500/30' : 'bg-gradient-to-br from-blue-50 to-purple-50 border-blue-200'} border rounded-xl`}>
            <div className="flex items-center gap-2 mb-2">
              <div className="h-2 w-2 bg-green-400 rounded-full animate-pulse"></div>
              <span className={`text-xs font-semibold ${darkMode ? 'text-gray-300' : 'text-gray-600'}`}>AI STATUS</span>
            </div>
            <p className={`text-sm ${darkMode ? 'text-white' : 'text-gray-900'} font-medium`}>All Systems Active</p>
            <p className={`text-xs ${darkMode ? 'text-gray-400' : 'text-gray-500'} mt-1`}>
              12 AI models running
            </p>
          </div>
        </aside>

        {/* Main Content */}
        <main className="flex-1 p-6">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
