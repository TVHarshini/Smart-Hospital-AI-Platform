import { useEffect, useState } from "react";
import { Heart, Activity, Thermometer, Wind, TrendingUp, AlertTriangle, Brain } from "lucide-react";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Area, AreaChart } from "recharts";
import { Badge } from "./ui/badge";
import { Progress } from "./ui/progress";

interface VitalData {
  time: string;
  heartRate: number;
  bloodPressureSys: number;
  bloodPressureDia: number;
  temperature: number;
  oxygen: number;
}

export default function VitalMonitoring() {
  const [currentHeartRate, setCurrentHeartRate] = useState(78);
  const [currentBP, setCurrentBP] = useState({ sys: 120, dia: 80 });
  const [currentTemp, setCurrentTemp] = useState(98.6);
  const [currentOxygen, setCurrentOxygen] = useState(98);
  const [healthScore, setHealthScore] = useState(87);
  const [heartBeatAnimation, setHeartBeatAnimation] = useState(false);

  const [vitalHistory, setVitalHistory] = useState<VitalData[]>([
    { time: "10:00", heartRate: 75, bloodPressureSys: 118, bloodPressureDia: 78, temperature: 98.4, oxygen: 97 },
    { time: "11:00", heartRate: 78, bloodPressureSys: 120, bloodPressureDia: 80, temperature: 98.5, oxygen: 98 },
    { time: "12:00", heartRate: 76, bloodPressureSys: 119, bloodPressureDia: 79, temperature: 98.6, oxygen: 98 },
    { time: "13:00", heartRate: 80, bloodPressureSys: 122, bloodPressureDia: 82, temperature: 98.7, oxygen: 97 },
    { time: "14:00", heartRate: 77, bloodPressureSys: 121, bloodPressureDia: 81, temperature: 98.6, oxygen: 98 },
    { time: "15:00", heartRate: 78, bloodPressureSys: 120, bloodPressureDia: 80, temperature: 98.6, oxygen: 98 },
  ]);

  // Simulate real-time vital signs
  useEffect(() => {
    const interval = setInterval(() => {
      // Update heart rate with realistic variation
      setCurrentHeartRate(prev => {
        const change = Math.floor(Math.random() * 6) - 3;
        return Math.max(60, Math.min(100, prev + change));
      });

      // Update blood pressure
      setCurrentBP(prev => ({
        sys: Math.max(110, Math.min(140, prev.sys + Math.floor(Math.random() * 4) - 2)),
        dia: Math.max(70, Math.min(90, prev.dia + Math.floor(Math.random() * 4) - 2))
      }));

      // Update temperature (slower changes)
      if (Math.random() > 0.7) {
        setCurrentTemp(prev => Math.max(97, Math.min(99, prev + (Math.random() > 0.5 ? 0.1 : -0.1))));
      }

      // Update oxygen
      setCurrentOxygen(prev => Math.max(95, Math.min(100, prev + Math.floor(Math.random() * 2) - 1)));

      // Heart beat animation
      setHeartBeatAnimation(true);
      setTimeout(() => setHeartBeatAnimation(false), 200);

      // Update history
      const currentTime = new Date();
      const timeStr = `${currentTime.getHours()}:${String(currentTime.getMinutes()).padStart(2, '0')}`;
      
      setVitalHistory(prev => {
        const newHistory = [...prev.slice(-5), {
          time: timeStr,
          heartRate: currentHeartRate,
          bloodPressureSys: currentBP.sys,
          bloodPressureDia: currentBP.dia,
          temperature: currentTemp,
          oxygen: currentOxygen
        }];
        return newHistory;
      });

      // Update health score
      setHealthScore(prev => {
        const change = Math.random() > 0.5 ? 1 : -1;
        return Math.max(75, Math.min(100, prev + change));
      });
    }, 2000);

    return () => clearInterval(interval);
  }, [currentHeartRate, currentBP, currentTemp, currentOxygen]);

  const getVitalStatus = (vital: string, value: number) => {
    const ranges = {
      heartRate: { normal: [60, 100], warning: [50, 110] },
      sys: { normal: [110, 130], warning: [100, 140] },
      dia: { normal: [70, 85], warning: [60, 90] },
      temp: { normal: [97.5, 99.0], warning: [97.0, 99.5] },
      oxygen: { normal: [95, 100], warning: [90, 95] }
    };

    const range = ranges[vital as keyof typeof ranges];
    if (!range) return "normal";

    if (value >= range.normal[0] && value <= range.normal[1]) return "normal";
    if (value >= range.warning[0] && value <= range.warning[1]) return "warning";
    return "critical";
  };

  const getStatusColor = (status: string) => {
    return status === "normal" ? "text-green-400" : status === "warning" ? "text-yellow-400" : "text-red-400";
  };

  const hrStatus = getVitalStatus("heartRate", currentHeartRate);
  const bpSysStatus = getVitalStatus("sys", currentBP.sys);
  const bpDiaStatus = getVitalStatus("dia", currentBP.dia);
  const tempStatus = getVitalStatus("temp", currentTemp);
  const oxygenStatus = getVitalStatus("oxygen", currentOxygen);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-3xl font-bold text-white mb-2">Real-Time Vital Monitoring</h2>
        <p className="text-gray-400">Live patient health metrics with AI analysis</p>
      </div>

      {/* Live Status Badge */}
      <div className="flex items-center gap-4">
        <Badge className="bg-green-500/20 text-green-400 border-green-500/30 px-4 py-2">
          <div className="h-2 w-2 bg-green-400 rounded-full animate-pulse mr-2"></div>
          LIVE MONITORING
        </Badge>
        <Badge className="bg-purple-500/20 text-purple-400 border-purple-500/30 px-4 py-2">
          <Brain className="h-3 w-3 mr-2" />
          AI ANALYSIS ACTIVE
        </Badge>
      </div>

      {/* Main Vitals Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {/* Heart Rate */}
        <div className="bg-gradient-to-br from-pink-900/30 to-rose-900/30 backdrop-blur-sm border border-pink-500/30 rounded-xl p-6 relative overflow-hidden">
          <div className="absolute top-0 right-0 opacity-10">
            <Heart className="h-32 w-32 text-pink-400" />
          </div>
          <div className="relative">
            <div className="flex items-center justify-between mb-4">
              <div className={`p-3 bg-pink-500/20 rounded-lg ${heartBeatAnimation ? 'scale-110' : 'scale-100'} transition-transform`}>
                <Heart className={`h-6 w-6 ${getStatusColor(hrStatus)}`} />
              </div>
              <Badge className={`${
                hrStatus === "normal" 
                  ? "bg-green-500/20 text-green-400 border-green-500/30"
                  : hrStatus === "warning"
                  ? "bg-yellow-500/20 text-yellow-400 border-yellow-500/30"
                  : "bg-red-500/20 text-red-400 border-red-500/30"
              }`}>
                {hrStatus.toUpperCase()}
              </Badge>
            </div>
            <p className="text-gray-400 text-sm mb-2">Heart Rate</p>
            <div className="flex items-baseline gap-2">
              <p className={`text-4xl font-bold ${getStatusColor(hrStatus)}`}>{currentHeartRate}</p>
              <p className="text-gray-400">BPM</p>
            </div>
            <div className="mt-4">
              <Progress value={(currentHeartRate / 100) * 100} className="h-2" />
            </div>
            <p className="text-xs text-gray-500 mt-2">Normal: 60-100 BPM</p>
          </div>
        </div>

        {/* Blood Pressure */}
        <div className="bg-gradient-to-br from-red-900/30 to-orange-900/30 backdrop-blur-sm border border-red-500/30 rounded-xl p-6 relative overflow-hidden">
          <div className="absolute top-0 right-0 opacity-10">
            <Activity className="h-32 w-32 text-red-400" />
          </div>
          <div className="relative">
            <div className="flex items-center justify-between mb-4">
              <div className="p-3 bg-red-500/20 rounded-lg">
                <Activity className={`h-6 w-6 ${getStatusColor(bpSysStatus)}`} />
              </div>
              <Badge className={`${
                bpSysStatus === "normal" && bpDiaStatus === "normal"
                  ? "bg-green-500/20 text-green-400 border-green-500/30"
                  : "bg-yellow-500/20 text-yellow-400 border-yellow-500/30"
              }`}>
                {bpSysStatus === "normal" && bpDiaStatus === "normal" ? "NORMAL" : "MONITOR"}
              </Badge>
            </div>
            <p className="text-gray-400 text-sm mb-2">Blood Pressure</p>
            <div className="flex items-baseline gap-2">
              <p className={`text-4xl font-bold ${getStatusColor(bpSysStatus)}`}>{currentBP.sys}</p>
              <p className="text-2xl font-bold text-gray-500">/</p>
              <p className={`text-4xl font-bold ${getStatusColor(bpDiaStatus)}`}>{currentBP.dia}</p>
            </div>
            <p className="text-gray-400 text-sm mt-1">mmHg</p>
            <p className="text-xs text-gray-500 mt-3">Normal: 120/80 mmHg</p>
          </div>
        </div>

        {/* Temperature */}
        <div className="bg-gradient-to-br from-orange-900/30 to-yellow-900/30 backdrop-blur-sm border border-orange-500/30 rounded-xl p-6 relative overflow-hidden">
          <div className="absolute top-0 right-0 opacity-10">
            <Thermometer className="h-32 w-32 text-orange-400" />
          </div>
          <div className="relative">
            <div className="flex items-center justify-between mb-4">
              <div className="p-3 bg-orange-500/20 rounded-lg">
                <Thermometer className={`h-6 w-6 ${getStatusColor(tempStatus)}`} />
              </div>
              <Badge className={`${
                tempStatus === "normal" 
                  ? "bg-green-500/20 text-green-400 border-green-500/30"
                  : "bg-yellow-500/20 text-yellow-400 border-yellow-500/30"
              }`}>
                {tempStatus.toUpperCase()}
              </Badge>
            </div>
            <p className="text-gray-400 text-sm mb-2">Body Temperature</p>
            <div className="flex items-baseline gap-2">
              <p className={`text-4xl font-bold ${getStatusColor(tempStatus)}`}>{currentTemp.toFixed(1)}</p>
              <p className="text-gray-400">°F</p>
            </div>
            <div className="mt-4">
              <Progress value={((currentTemp - 95) / 5) * 100} className="h-2" />
            </div>
            <p className="text-xs text-gray-500 mt-2">Normal: 97.5-99°F</p>
          </div>
        </div>

        {/* Oxygen Level */}
        <div className="bg-gradient-to-br from-blue-900/30 to-cyan-900/30 backdrop-blur-sm border border-blue-500/30 rounded-xl p-6 relative overflow-hidden">
          <div className="absolute top-0 right-0 opacity-10">
            <Wind className="h-32 w-32 text-blue-400" />
          </div>
          <div className="relative">
            <div className="flex items-center justify-between mb-4">
              <div className="p-3 bg-blue-500/20 rounded-lg">
                <Wind className={`h-6 w-6 ${getStatusColor(oxygenStatus)}`} />
              </div>
              <Badge className={`${
                oxygenStatus === "normal" 
                  ? "bg-green-500/20 text-green-400 border-green-500/30"
                  : "bg-yellow-500/20 text-yellow-400 border-yellow-500/30"
              }`}>
                {oxygenStatus.toUpperCase()}
              </Badge>
            </div>
            <p className="text-gray-400 text-sm mb-2">Oxygen Saturation</p>
            <div className="flex items-baseline gap-2">
              <p className={`text-4xl font-bold ${getStatusColor(oxygenStatus)}`}>{currentOxygen}</p>
              <p className="text-gray-400">%</p>
            </div>
            <div className="mt-4">
              <Progress value={currentOxygen} className="h-2" />
            </div>
            <p className="text-xs text-gray-500 mt-2">Normal: 95-100%</p>
          </div>
        </div>
      </div>

      {/* Health Score */}
      <div className="bg-gradient-to-br from-purple-900/30 to-indigo-900/30 backdrop-blur-sm border border-purple-500/30 rounded-xl p-6">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h3 className="text-xl font-semibold text-white mb-1">AI Health Stability Score</h3>
            <p className="text-gray-400 text-sm">Calculated from all vital parameters</p>
          </div>
          <div className="text-right">
            <p className="text-5xl font-bold bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
              {healthScore}
            </p>
            <p className="text-gray-400 text-sm">/ 100</p>
          </div>
        </div>
        <Progress value={healthScore} className="h-3 mb-4" />
        <div className="flex items-center gap-2 text-sm">
          {healthScore >= 85 ? (
            <>
              <TrendingUp className="h-4 w-4 text-green-400" />
              <span className="text-green-400 font-medium">Excellent Health Status</span>
            </>
          ) : healthScore >= 70 ? (
            <>
              <AlertTriangle className="h-4 w-4 text-yellow-400" />
              <span className="text-yellow-400 font-medium">Monitor Closely</span>
            </>
          ) : (
            <>
              <AlertTriangle className="h-4 w-4 text-red-400" />
              <span className="text-red-400 font-medium">Requires Attention</span>
            </>
          )}
        </div>
      </div>

      {/* Vital Trends */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Heart Rate Trend */}
        <div className="bg-slate-900/50 backdrop-blur-sm border border-slate-700/50 rounded-xl p-6">
          <div className="flex items-center gap-2 mb-6">
            <Heart className="h-5 w-5 text-pink-400" />
            <h3 className="text-lg font-semibold text-white">Heart Rate Trend</h3>
            <Badge className="ml-auto bg-green-500/20 text-green-400 border-green-500/30">
              <div className="h-2 w-2 bg-green-400 rounded-full animate-pulse mr-1"></div>
              LIVE
            </Badge>
          </div>
          <ResponsiveContainer width="100%" height={200}>
            <AreaChart data={vitalHistory}>
              <defs>
                <linearGradient id="colorHR" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#ec4899" stopOpacity={0.3}/>
                  <stop offset="95%" stopColor="#ec4899" stopOpacity={0}/>
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
              <XAxis dataKey="time" stroke="#9ca3af" />
              <YAxis stroke="#9ca3af" domain={[60, 100]} />
              <Tooltip 
                contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #475569', borderRadius: '8px' }}
                labelStyle={{ color: '#e5e7eb' }}
              />
              <Area 
                type="monotone" 
                dataKey="heartRate" 
                stroke="#ec4899" 
                strokeWidth={2}
                fillOpacity={1}
                fill="url(#colorHR)"
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Blood Pressure Trend */}
        <div className="bg-slate-900/50 backdrop-blur-sm border border-slate-700/50 rounded-xl p-6">
          <div className="flex items-center gap-2 mb-6">
            <Activity className="h-5 w-5 text-red-400" />
            <h3 className="text-lg font-semibold text-white">Blood Pressure Trend</h3>
            <Badge className="ml-auto bg-green-500/20 text-green-400 border-green-500/30">
              <div className="h-2 w-2 bg-green-400 rounded-full animate-pulse mr-1"></div>
              LIVE
            </Badge>
          </div>
          <ResponsiveContainer width="100%" height={200}>
            <LineChart data={vitalHistory}>
              <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
              <XAxis dataKey="time" stroke="#9ca3af" />
              <YAxis stroke="#9ca3af" domain={[60, 140]} />
              <Tooltip 
                contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #475569', borderRadius: '8px' }}
                labelStyle={{ color: '#e5e7eb' }}
              />
              <Line 
                type="monotone" 
                dataKey="bloodPressureSys" 
                stroke="#ef4444" 
                strokeWidth={2}
                dot={{ fill: '#ef4444', r: 3 }}
                name="Systolic"
              />
              <Line 
                type="monotone" 
                dataKey="bloodPressureDia" 
                stroke="#f97316" 
                strokeWidth={2}
                dot={{ fill: '#f97316', r: 3 }}
                name="Diastolic"
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* AI Anomaly Detection */}
      <div className="bg-slate-900/50 backdrop-blur-sm border border-slate-700/50 rounded-xl p-6">
        <div className="flex items-center gap-2 mb-4">
          <Brain className="h-5 w-5 text-purple-400" />
          <h3 className="text-lg font-semibold text-white">AI Anomaly Detection</h3>
        </div>
        <div className="space-y-3">
          {hrStatus !== "normal" && (
            <div className="p-4 bg-yellow-500/10 border border-yellow-500/20 rounded-lg">
              <div className="flex items-center gap-2 mb-1">
                <AlertTriangle className="h-4 w-4 text-yellow-400" />
                <span className="text-yellow-400 font-medium">Heart Rate Alert</span>
              </div>
              <p className="text-sm text-gray-300">
                Current heart rate ({currentHeartRate} BPM) is outside normal range. AI suggests monitoring closely.
              </p>
            </div>
          )}
          {(bpSysStatus !== "normal" || bpDiaStatus !== "normal") && (
            <div className="p-4 bg-yellow-500/10 border border-yellow-500/20 rounded-lg">
              <div className="flex items-center gap-2 mb-1">
                <AlertTriangle className="h-4 w-4 text-yellow-400" />
                <span className="text-yellow-400 font-medium">Blood Pressure Alert</span>
              </div>
              <p className="text-sm text-gray-300">
                Blood pressure ({currentBP.sys}/{currentBP.dia} mmHg) requires attention. Consider medical consultation.
              </p>
            </div>
          )}
          {hrStatus === "normal" && bpSysStatus === "normal" && bpDiaStatus === "normal" && tempStatus === "normal" && oxygenStatus === "normal" && (
            <div className="p-4 bg-green-500/10 border border-green-500/20 rounded-lg">
              <div className="flex items-center gap-2 mb-1">
                <TrendingUp className="h-4 w-4 text-green-400" />
                <span className="text-green-400 font-medium">All Vitals Normal</span>
              </div>
              <p className="text-sm text-gray-300">
                No anomalies detected. All vital signs are within healthy ranges.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
