import { createBrowserRouter } from "react-router";
import Root from "./components/Root";
import Dashboard from "./components/Dashboard";
import Requests from "./components/Requests";
import HomeService from "./components/HomeService";
import Emergency from "./components/Emergency";
import Appointments from "./components/Appointments";
import VitalMonitoring from "./components/VitalMonitoring";
import Analytics from "./components/Analytics";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: Root,
    children: [
      { index: true, Component: Dashboard },
      { path: "requests", Component: Requests },
      { path: "home-service", Component: HomeService },
      { path: "emergency", Component: Emergency },
      { path: "appointments", Component: Appointments },
      { path: "vital-monitoring", Component: VitalMonitoring },
      { path: "analytics", Component: Analytics },
    ],
  },
]);
